
import { Locator, Page } from '@playwright/test'

export class SendMoney {
  readonly page: Page
  readonly nav: Locator
  readonly pageHeader: Locator
  readonly fromAccountTrigger: Locator
  readonly fromAccountOption: Locator
  readonly recipientInput: Locator
  readonly payeeTrigger: Locator
  readonly payeeOption: Locator
  readonly amountInput: Locator
  readonly noteInput: Locator
  readonly reviewSendButton: Locator
  readonly submitButton: Locator
  readonly confirmationDialog: Locator
  readonly confirmTransferButton: Locator
  readonly validationMessage: Locator
  readonly successMessage: Locator
  readonly errorForHigherAmt: Locator
  readonly transactionId: Locator
  readonly balanceSummary: Locator
  readonly historyTable: Locator
  readonly pageTitle: Locator

  constructor(page: Page) {
    this.page = page
    this.nav = this.page.locator('[data-nav="send-money"]')
    this.pageHeader = this.page.getByRole('heading', { name: /send money/i })
    this.pageTitle = this.page.locator('h1, h2')

    this.fromAccountTrigger = this.page.locator('#send-from-trigger')
    this.fromAccountOption = this.page.locator('[data-account-id="acc-checking-1"], [data-account-id="acc-checking"], text=Everyday Checking')

    this.recipientInput = this.page.locator('#send-recipient, #recipient-account, #account-number, input[name*="recipient"], input[aria-label*="recipient" i]')
    this.payeeTrigger = this.page.locator('#payee-select-trigger, #send-payee-trigger, [data-testid="payee-select"]')
    this.payeeOption = this.page.getByRole('option')

    this.amountInput = this.page.locator('#send-amount, #transfer-amount, input[name*="amount"], input[aria-label*="amount" i]')
    this.noteInput = this.page.locator('#send-note, #transfer-note, textarea[name*="note"], input[name*="note"]')

    this.reviewSendButton = this.page.getByRole('button', { name: /review.*send|send.*review/i })
    this.submitButton = this.page.getByRole('button', { name: /send|submit|transfer/i })
    this.confirmationDialog = this.page.getByText(/confirm.*send|confirm.*transfer/i)
    this.confirmTransferButton = this.page.getByRole('button', { name: /confirm.*send|confirm.*transfer/i })

    this.validationMessage = this.page.locator('[role="alert"], .error, [data-testid="validation-message"], .toast-message, .validation-message, .text-danger')
    this.successMessage = this.page.getByText(/money sent successfully|transfer successful|payment sent successfully|transaction successful/i)
    this.errorForHigherAmt = this.page.getByText(/insufficient funds.*available balance|insufficient balance|exceeds available balance/i)

    this.transactionId = this.page.locator('[data-testid="transaction-id"], .transaction-id, text=/TRX|REF|TXN/i')
    this.balanceSummary = this.page.locator('[data-testid="balance"], .balance, [data-account-id="acc-checking-1"]')
    this.historyTable = this.page.locator('table, [data-testid="transaction-history"], .transaction-history, .history-table')
  }

  async openSendMoneyPage() {
    await this.nav.click()
    await this.pageHeader.waitFor({ state: 'visible' })
  }

  async selectFromAccount(accountName = 'Everyday Checking') {
    await this.fromAccountTrigger.click()
    const option = this.page.getByText(accountName, { exact: false })
    if (await option.count()) {
      await option.first().click()
      return
    }
    await this.fromAccountOption.click()
  }

  async selectPayee(payeeValue: string | number) {
    await this.payeeTrigger.click()

    if (typeof payeeValue === 'number') {
      await this.payeeOption.nth(payeeValue).click()
      return
    }

    await this.page.getByRole('option', { name: new RegExp(payeeValue, 'i') }).first().click()
  }

  async fillRecipient(recipient: string) {
    await this.recipientInput.fill(recipient)
  }

  async fillAmount(amount: string) {
    await this.amountInput.fill(amount)
  }

  async fillNote(note: string) {
    await this.noteInput.fill(note)
  }

  async clickReviewSend() {
    await this.reviewSendButton.click()
  }

  async confirmTransfer() {
    if (await this.confirmTransferButton.count()) {
      await this.confirmTransferButton.click()
      return
    }

    if (await this.confirmationDialog.count()) {
      await this.confirmationDialog.click()
    }
  }

  async submitTransfer({ recipient = '', amount = '', note = '', payee = 0, accountName = 'Everyday Checking' } = {}) {
    await this.openSendMoneyPage()
    await this.selectFromAccount(accountName)

    if (recipient) {
      await this.fillRecipient(recipient)
    }

    if (typeof payee === 'number') {
      await this.selectPayee(payee)
    } else {
      await this.selectPayee(payee)
    }

    await this.fillAmount(amount)
    await this.fillNote(note)
    await this.clickReviewSend()

    if (await this.confirmTransferButton.count()) {
      await this.confirmTransferButton.click()
    }
  }

  async sendMoneyToPayee() {
    await this.openSendMoneyPage()
  }

  async SendMoneytoOther(amount: string, note: string, payee: number) {
    await this.openSendMoneyPage()
    await this.selectFromAccount()
    await this.selectPayee(payee)
    await this.fillAmount(amount)
    await this.fillNote(note)
    await this.clickReviewSend()

    if (await this.confirmTransferButton.count()) {
      await this.confirmTransferButton.click()
    }
  }

  async getValidationText() {
    return this.validationMessage.first().textContent()
  }

  async getSuccessText() {
    return this.successMessage.first().textContent()
  }

  async getBalanceText() {
    return this.balanceSummary.first().textContent()
  }

  async getTransactionIdText() {
    return this.transactionId.first().textContent()
  }

  async hasTransactionInHistory(transactionText: string) {
    return this.page.getByText(transactionText, { exact: false }).isVisible()
  }
}

export { SendMoney as sendMoney }

